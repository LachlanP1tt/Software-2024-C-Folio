﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2.Height_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_Click(object sender, EventArgs e)
        {

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            int height1 = int.Parse(txtHeight1.Text);
            int height2 = int.Parse(txtHeight2.Text);
            int height3 = int.Parse(txtHeight3.Text);
            int height4 = int.Parse(txtHeight4.Text);
            int height5 = int.Parse(txtHeight5.Text);

            // Total

            double total = height1 + height2 + height3 + height4 + height5;
            lblTotal.Text = "Total Height: " + total.ToString() + "cm";

            // Average (cm)

            double averageCM = Math.Round(total / 5);
            lblAverageCM.Text = "Average Height (cm): " + averageCM.ToString() + "cm";

            // Average (m)

            double averageM = averageCM / 100;
            lblAverageM.Text = "Average Height (m): " + averageM.ToString() + "m";

        }
    }
}
